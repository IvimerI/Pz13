using System.Windows;
using AssetManagementAuthApp.Pages;

namespace AssetManagementAuthApp;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        MainFrame.Navigate(new LoginPage(MainFrame));
    }
}
