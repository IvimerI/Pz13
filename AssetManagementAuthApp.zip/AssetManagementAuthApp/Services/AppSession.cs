using AssetManagementAuthApp.Models;

namespace AssetManagementAuthApp.Services;

public static class AppSession
{
    public static UserSession? CurrentUser { get; private set; }

    public static bool IsAuthenticated => CurrentUser != null;

    public static void Set(UserSession user) => CurrentUser = user;

    public static void Clear() => CurrentUser = null;
}
