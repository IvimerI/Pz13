namespace AssetManagementAuthApp.Services;

public static class DatabaseConfig
{
    public const string ConnectionString = "Server=(local)\\SQLEXPRESS;Database=AssetManagementDB;Trusted_Connection=True;TrustServerCertificate=True;";
}
