using System;
using AssetManagementAuthApp.Models;
using Microsoft.Data.SqlClient;

namespace AssetManagementAuthApp.Services;

public static class AuthService
{
    public static bool TryAuthenticate(string loginOrEmail, string password, out UserSession? session, out string errorMessage)
    {
        session = null;
        errorMessage = string.Empty;

        if (string.IsNullOrWhiteSpace(loginOrEmail) || string.IsNullOrWhiteSpace(password))
        {
            errorMessage = "Введите логин/email и пароль.";
            return false;
        }

        try
        {
            session = TryAuthenticateFromDatabase(loginOrEmail.Trim());
            if (session != null)
            {
                if (session.IsBlocked)
                {
                    errorMessage = "Учетная запись заблокирована администратором.";
                    return false;
                }

                AppSession.Set(session);
                return true;
            }
        }
        catch
        {
        }

        session = TryAuthenticateFallback(loginOrEmail.Trim(), password.Trim());
        if (session != null)
        {
            AppSession.Set(session);
            return true;
        }

        errorMessage = "Пользователь не найден. Для демо-входа используйте admin/admin, manager/manager или user/user.";
        return false;
    }

    private static UserSession? TryAuthenticateFromDatabase(string loginOrEmail)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        var hasIsBlocked = HasIsBlockedColumn(connection);
        var isBlockedSelect = hasIsBlocked ? ", su.is_blocked" : ", CAST(0 AS bit) AS is_blocked";

        var sql = $@"
SELECT TOP 1
    su.user_code,
    su.employee_code,
    su.login_name,
    e.full_name,
    e.email,
    su.role_code,
    ar.role_name
    {isBlockedSelect}
FROM asset_mgmt.system_users su
INNER JOIN asset_mgmt.employees e ON e.employee_code = su.employee_code
INNER JOIN asset_mgmt.app_roles ar ON ar.role_code = su.role_code
WHERE su.is_active = 1
  AND (su.login_name = @login OR e.email = @login)
ORDER BY su.user_code;";

        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@login", loginOrEmail);
        using var reader = command.ExecuteReader();

        if (!reader.Read())
            return null;

        var roleCode = reader["role_code"]?.ToString() ?? "USER";
        return new UserSession
        {
            UserCode = reader["user_code"]?.ToString() ?? string.Empty,
            EmployeeCode = reader["employee_code"]?.ToString() ?? string.Empty,
            LoginName = reader["login_name"]?.ToString() ?? string.Empty,
            FullName = reader["full_name"]?.ToString() ?? string.Empty,
            Email = reader["email"]?.ToString() ?? string.Empty,
            RoleCode = roleCode,
            RoleName = reader["role_name"]?.ToString() ?? string.Empty,
            Role = ParseRole(roleCode),
            IsBlocked = reader["is_blocked"] != DBNull.Value && Convert.ToBoolean(reader["is_blocked"])
        };
    }

    public static UserRole ParseRole(string? roleCode) => (roleCode ?? string.Empty).ToUpperInvariant() switch
    {
        "ADMIN" => UserRole.Admin,
        "MANAGER" => UserRole.Manager,
        _ => UserRole.User
    };

    public static bool HasIsBlockedColumn(SqlConnection connection)
    {
        const string sql = @"
SELECT COUNT(*)
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'asset_mgmt'
  AND TABLE_NAME = 'system_users'
  AND COLUMN_NAME = 'is_blocked';";

        using var command = new SqlCommand(sql, connection);
        var count = Convert.ToInt32(command.ExecuteScalar());
        return count > 0;
    }

    private static UserSession? TryAuthenticateFallback(string login, string password)
    {
        if (login.Equals("admin", StringComparison.OrdinalIgnoreCase) && password == "admin")
        {
            return new UserSession
            {
                UserCode = "DEMO001",
                EmployeeCode = "EMP001",
                LoginName = "admin",
                FullName = "Демо Администратор",
                Email = "admin@demo.local",
                RoleCode = "ADMIN",
                RoleName = "Администратор",
                Role = UserRole.Admin
            };
        }

        if (login.Equals("manager", StringComparison.OrdinalIgnoreCase) && password == "manager")
        {
            return new UserSession
            {
                UserCode = "DEMO002",
                EmployeeCode = "EMP002",
                LoginName = "manager",
                FullName = "Демо Менеджер",
                Email = "manager@demo.local",
                RoleCode = "MANAGER",
                RoleName = "Менеджер",
                Role = UserRole.Manager
            };
        }

        if (login.Equals("user", StringComparison.OrdinalIgnoreCase) && password == "user")
        {
            return new UserSession
            {
                UserCode = "DEMO003",
                EmployeeCode = "EMP003",
                LoginName = "user",
                FullName = "Демо Пользователь",
                Email = "user@demo.local",
                RoleCode = "USER",
                RoleName = "Пользователь",
                Role = UserRole.User
            };
        }

        return null;
    }
}
