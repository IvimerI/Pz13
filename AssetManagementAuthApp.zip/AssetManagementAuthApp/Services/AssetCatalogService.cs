using System;
using System.Collections.Generic;
using System.IO;
using AssetManagementAuthApp.Models;
using Microsoft.Data.SqlClient;

namespace AssetManagementAuthApp.Services;

public static class AssetCatalogService
{
    public static List<AssetCardItem> GetAssets(string? search = null, string? categoryCode = null, string? statusCode = null, string? sortField = null, bool descending = false)
    {
        var result = new List<AssetCardItem>();

        try
        {
            using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
            connection.Open();

            var orderBy = sortField switch
            {
                "Наименование" => "a.asset_name",
                "Категория" => "c.category_name",
                "Статус" => "s.status_name",
                "Стоимость" => "a.current_value",
                "Дата приобретения" => "a.acquisition_date",
                _ => "a.asset_name"
            };

            var sql = $@"
SELECT
    a.asset_code,
    a.asset_name,
    c.category_name,
    s.status_name,
    l.location_name,
    a.current_value,
    a.image,
    a.notes
FROM asset_mgmt.assets a
INNER JOIN asset_mgmt.asset_categories c ON c.category_code = a.category_code
INNER JOIN asset_mgmt.asset_statuses s ON s.status_code = a.status_code
INNER JOIN asset_mgmt.locations l ON l.location_code = a.location_code
WHERE (@search IS NULL OR a.asset_name LIKE '%' + @search + '%' OR ISNULL(a.notes, '') LIKE '%' + @search + '%')
  AND (@categoryCode IS NULL OR a.category_code = @categoryCode)
  AND (@statusCode IS NULL OR a.status_code = @statusCode)
ORDER BY {orderBy} {(descending ? "DESC" : "ASC")};";

            using var command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@search", string.IsNullOrWhiteSpace(search) ? DBNull.Value : search.Trim());
            command.Parameters.AddWithValue("@categoryCode", string.IsNullOrWhiteSpace(categoryCode) ? DBNull.Value : categoryCode);
            command.Parameters.AddWithValue("@statusCode", string.IsNullOrWhiteSpace(statusCode) ? DBNull.Value : statusCode);

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                result.Add(new AssetCardItem
                {
                    AssetCode = reader["asset_code"]?.ToString() ?? string.Empty,
                    AssetName = reader["asset_name"]?.ToString() ?? string.Empty,
                    CategoryName = reader["category_name"]?.ToString() ?? string.Empty,
                    StatusName = reader["status_name"]?.ToString() ?? string.Empty,
                    LocationName = reader["location_name"]?.ToString() ?? string.Empty,
                    CurrentValue = reader["current_value"] == DBNull.Value ? 0 : Convert.ToDecimal(reader["current_value"]),
                    ImageBytes = reader["image"] == DBNull.Value ? null : (byte[])reader["image"],
                    Notes = reader["notes"] == DBNull.Value ? string.Empty : reader["notes"].ToString() ?? string.Empty
                });
            }
        }
        catch
        {
            return GetFallbackAssets();
        }

        return result.Count > 0 ? result : GetFallbackAssets();
    }

    public static AssetFilterOptions GetFilterOptions()
    {
        var options = new AssetFilterOptions();

        try
        {
            using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
            connection.Open();

            options.Categories = ReadLookup(connection, "SELECT category_code, category_name FROM asset_mgmt.asset_categories ORDER BY category_name;");
            options.Statuses = ReadLookup(connection, "SELECT status_code, status_name FROM asset_mgmt.asset_statuses ORDER BY status_name;");
            options.Locations = ReadLookup(connection, "SELECT location_code, location_name FROM asset_mgmt.locations ORDER BY location_name;");
            options.Employees = ReadLookup(connection, "SELECT employee_code, full_name FROM asset_mgmt.employees ORDER BY full_name;");
            options.Vendors = ReadLookup(connection, "SELECT vendor_code, vendor_name FROM asset_mgmt.vendors ORDER BY vendor_name;");
        }
        catch
        {
            options.Categories = new List<LookupItem>
            {
                new() { Code = "CAT004", Name = "Компьютерная техника" },
                new() { Code = "CAT005", Name = "Серверное оборудование" },
                new() { Code = "CAT014", Name = "Системы безопасности" }
            };
            options.Statuses = new List<LookupItem>
            {
                new() { Code = "ST001", Name = "В эксплуатации" },
                new() { Code = "ST002", Name = "На складе" },
                new() { Code = "ST004", Name = "В ремонте" }
            };
            options.Locations = new List<LookupItem>
            {
                new() { Code = "LOC001", Name = "Главный офис" },
                new() { Code = "LOC003", Name = "Серверная" }
            };
            options.Employees = new List<LookupItem>
            {
                new() { Code = "EMP001", Name = "Иванов Иван Иванович" },
                new() { Code = "EMP002", Name = "Петров Петр Петрович" }
            };
            options.Vendors = new List<LookupItem>
            {
                new() { Code = "VEN001", Name = "ООО Технопоставка" },
                new() { Code = "VEN002", Name = "АО ИнфоСистемы" }
            };
        }

        return options;
    }

    public static AssetEditItem? GetAssetByCode(string assetCode)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        const string sql = @"
SELECT
    asset_code, asset_name, category_code, inventory_number, serial_number, barcode,
    acquisition_date, initial_cost, current_value, useful_life_months,
    status_code, location_code, responsible_code, vendor_code, notes, image
FROM asset_mgmt.assets
WHERE asset_code = @assetCode;";

        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@assetCode", assetCode);
        using var reader = command.ExecuteReader();

        if (!reader.Read())
            return null;

        return new AssetEditItem
        {
            AssetCode = reader["asset_code"]?.ToString() ?? string.Empty,
            AssetName = reader["asset_name"]?.ToString() ?? string.Empty,
            CategoryCode = reader["category_code"]?.ToString() ?? string.Empty,
            InventoryNumber = reader["inventory_number"]?.ToString() ?? string.Empty,
            SerialNumber = reader["serial_number"]?.ToString() ?? string.Empty,
            Barcode = reader["barcode"] == DBNull.Value ? string.Empty : reader["barcode"]?.ToString() ?? string.Empty,
            AcquisitionDate = reader["acquisition_date"] == DBNull.Value ? DateTime.Today : Convert.ToDateTime(reader["acquisition_date"]),
            InitialCost = reader["initial_cost"] == DBNull.Value ? 0 : Convert.ToDecimal(reader["initial_cost"]),
            CurrentValue = reader["current_value"] == DBNull.Value ? 0 : Convert.ToDecimal(reader["current_value"]),
            UsefulLifeMonths = reader["useful_life_months"] == DBNull.Value ? 12 : Convert.ToInt32(reader["useful_life_months"]),
            StatusCode = reader["status_code"]?.ToString() ?? string.Empty,
            LocationCode = reader["location_code"]?.ToString() ?? string.Empty,
            ResponsibleCode = reader["responsible_code"]?.ToString() ?? string.Empty,
            VendorCode = reader["vendor_code"] == DBNull.Value ? string.Empty : reader["vendor_code"]?.ToString() ?? string.Empty,
            Notes = reader["notes"] == DBNull.Value ? string.Empty : reader["notes"]?.ToString() ?? string.Empty,
            ImageBytes = reader["image"] == DBNull.Value ? null : (byte[])reader["image"]
        };
    }

    public static void AddAsset(AssetEditItem item)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        const string sql = @"
INSERT INTO asset_mgmt.assets
(
    asset_code, asset_name, category_code, inventory_number, serial_number, barcode,
    acquisition_date, initial_cost, current_value, useful_life_months,
    status_code, location_code, responsible_code, vendor_code, notes, image
)
VALUES
(
    @asset_code, @asset_name, @category_code, @inventory_number, @serial_number, @barcode,
    @acquisition_date, @initial_cost, @current_value, @useful_life_months,
    @status_code, @location_code, @responsible_code, @vendor_code, @notes, @image
);";

        using var command = CreateAssetCommand(connection, sql, item);
        command.ExecuteNonQuery();
    }

    public static void UpdateAsset(AssetEditItem item)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        const string sql = @"
UPDATE asset_mgmt.assets
SET
    asset_name = @asset_name,
    category_code = @category_code,
    inventory_number = @inventory_number,
    serial_number = @serial_number,
    barcode = @barcode,
    acquisition_date = @acquisition_date,
    initial_cost = @initial_cost,
    current_value = @current_value,
    useful_life_months = @useful_life_months,
    status_code = @status_code,
    location_code = @location_code,
    responsible_code = @responsible_code,
    vendor_code = @vendor_code,
    notes = @notes,
    image = @image
WHERE asset_code = @asset_code;";

        using var command = CreateAssetCommand(connection, sql, item);
        command.ExecuteNonQuery();
    }

    public static void DeleteAsset(string assetCode)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        using var transaction = connection.BeginTransaction();
        try
        {
            var deleteSqls = new[]
            {
                "DELETE FROM asset_mgmt.asset_movements WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.inventory_results WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.maintenance_events WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.maintenance_plans WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.revaluation_history WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.depreciation_history WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.documents WHERE asset_code = @assetCode;",
                "DELETE FROM asset_mgmt.assets WHERE asset_code = @assetCode;"
            };

            foreach (var sql in deleteSqls)
            {
                using var command = new SqlCommand(sql, connection, transaction);
                command.Parameters.AddWithValue("@assetCode", assetCode);
                command.ExecuteNonQuery();
            }

            transaction.Commit();
        }
        catch
        {
            transaction.Rollback();
            throw;
        }
    }

    private static SqlCommand CreateAssetCommand(SqlConnection connection, string sql, AssetEditItem item)
    {
        var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@asset_code", item.AssetCode);
        command.Parameters.AddWithValue("@asset_name", item.AssetName);
        command.Parameters.AddWithValue("@category_code", item.CategoryCode);
        command.Parameters.AddWithValue("@inventory_number", item.InventoryNumber);
        command.Parameters.AddWithValue("@serial_number", item.SerialNumber);
        command.Parameters.AddWithValue("@barcode", string.IsNullOrWhiteSpace(item.Barcode) ? DBNull.Value : item.Barcode);
        command.Parameters.AddWithValue("@acquisition_date", item.AcquisitionDate);
        command.Parameters.AddWithValue("@initial_cost", item.InitialCost);
        command.Parameters.AddWithValue("@current_value", item.CurrentValue);
        command.Parameters.AddWithValue("@useful_life_months", item.UsefulLifeMonths);
        command.Parameters.AddWithValue("@status_code", item.StatusCode);
        command.Parameters.AddWithValue("@location_code", item.LocationCode);
        command.Parameters.AddWithValue("@responsible_code", item.ResponsibleCode);
        command.Parameters.AddWithValue("@vendor_code", string.IsNullOrWhiteSpace(item.VendorCode) ? DBNull.Value : item.VendorCode);
        command.Parameters.AddWithValue("@notes", string.IsNullOrWhiteSpace(item.Notes) ? DBNull.Value : item.Notes);
        command.Parameters.AddWithValue("@image", item.ImageBytes == null || item.ImageBytes.Length == 0 ? DBNull.Value : item.ImageBytes);
        return command;
    }

    private static List<LookupItem> ReadLookup(SqlConnection connection, string sql)
    {
        var result = new List<LookupItem>();
        using var command = new SqlCommand(sql, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            result.Add(new LookupItem
            {
                Code = reader[0]?.ToString() ?? string.Empty,
                Name = reader[1]?.ToString() ?? string.Empty
            });
        }
        return result;
    }

    private static List<AssetCardItem> GetFallbackAssets()
    {
        var placeholder = File.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "logo.png"))
            ? File.ReadAllBytes(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "logo.png"))
            : null;

        return new List<AssetCardItem>
        {
            new() { AssetCode = "AST0001", AssetName = "Ноутбук Lenovo ThinkPad", CategoryName = "Компьютерная техника", StatusName = "В эксплуатации", LocationName = "Главный офис", CurrentValue = 82500, Notes = "Используется менеджером отдела продаж.", ImageBytes = placeholder },
            new() { AssetCode = "AST0002", AssetName = "Сервер Dell PowerEdge", CategoryName = "Серверное оборудование", StatusName = "На обслуживании", LocationName = "Серверная", CurrentValue = 245000, Notes = "Требуется плановое ТО в следующем месяце.", ImageBytes = placeholder },
            new() { AssetCode = "AST0003", AssetName = "IP-камера Hikvision", CategoryName = "Системы безопасности", StatusName = "На складе", LocationName = "Склад А", CurrentValue = 15400, Notes = "Подготовлена к установке в новом филиале.", ImageBytes = placeholder }
        };
    }
}
