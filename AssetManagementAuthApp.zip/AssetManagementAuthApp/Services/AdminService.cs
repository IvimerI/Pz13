using System;
using System.Collections.Generic;
using AssetManagementAuthApp.Models;
using Microsoft.Data.SqlClient;

namespace AssetManagementAuthApp.Services;

public static class AdminService
{
    public static List<UserAdminItem> GetUsers(string? search = null)
    {
        var users = new List<UserAdminItem>();

        try
        {
            using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
            connection.Open();

            var hasIsBlocked = AuthService.HasIsBlockedColumn(connection);
            var isBlockedSelect = hasIsBlocked ? ", su.is_blocked" : ", CAST(0 AS bit) AS is_blocked";

            var sql = $@"
SELECT
    su.user_code,
    su.employee_code,
    su.login_name,
    e.full_name,
    e.email,
    su.role_code,
    ar.role_name
    {isBlockedSelect}
FROM asset_mgmt.system_users su
INNER JOIN asset_mgmt.employees e ON e.employee_code = su.employee_code
INNER JOIN asset_mgmt.app_roles ar ON ar.role_code = su.role_code
WHERE (@search IS NULL
       OR su.login_name LIKE '%' + @search + '%'
       OR e.full_name LIKE '%' + @search + '%'
       OR e.email LIKE '%' + @search + '%')
ORDER BY e.full_name;";

            using var command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@search", string.IsNullOrWhiteSpace(search) ? DBNull.Value : search.Trim());
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                users.Add(new UserAdminItem
                {
                    UserCode = reader["user_code"]?.ToString() ?? string.Empty,
                    EmployeeCode = reader["employee_code"]?.ToString() ?? string.Empty,
                    LoginName = reader["login_name"]?.ToString() ?? string.Empty,
                    FullName = reader["full_name"]?.ToString() ?? string.Empty,
                    Email = reader["email"]?.ToString() ?? string.Empty,
                    RoleCode = reader["role_code"]?.ToString() ?? string.Empty,
                    RoleName = reader["role_name"]?.ToString() ?? string.Empty,
                    IsBlocked = reader["is_blocked"] != DBNull.Value && Convert.ToBoolean(reader["is_blocked"])
                });
            }
        }
        catch
        {
            users.AddRange(GetFallbackUsers(search));
        }

        return users;
    }

    public static List<LookupItem> GetRoles() => new()
    {
        new LookupItem { Code = "USER", Name = "Пользователь" },
        new LookupItem { Code = "MANAGER", Name = "Менеджер" },
        new LookupItem { Code = "ADMIN", Name = "Администратор" }
    };

    public static void UpdateUserRole(string userCode, string roleCode)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        const string sql = "UPDATE asset_mgmt.system_users SET role_code = @roleCode WHERE user_code = @userCode;";
        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@roleCode", roleCode);
        command.Parameters.AddWithValue("@userCode", userCode);
        command.ExecuteNonQuery();
    }

    public static void SetBlocked(string userCode, bool isBlocked)
    {
        using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
        connection.Open();

        if (!AuthService.HasIsBlockedColumn(connection))
        {
            using var alterCommand = new SqlCommand("ALTER TABLE asset_mgmt.system_users ADD is_blocked BIT NOT NULL CONSTRAINT DF_system_users_is_blocked DEFAULT 0;", connection);
            alterCommand.ExecuteNonQuery();
        }

        const string sql = "UPDATE asset_mgmt.system_users SET is_blocked = @isBlocked WHERE user_code = @userCode;";
        using var command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@isBlocked", isBlocked);
        command.Parameters.AddWithValue("@userCode", userCode);
        command.ExecuteNonQuery();
    }

    public static AnalyticsSummary GetAnalytics()
    {
        var summary = new AnalyticsSummary();

        try
        {
            using var connection = new SqlConnection(DatabaseConfig.ConnectionString);
            connection.Open();

            summary.TotalAssets = ExecuteInt(connection, "SELECT COUNT(*) FROM asset_mgmt.assets;");
            summary.TotalUsers = ExecuteInt(connection, "SELECT COUNT(*) FROM asset_mgmt.system_users;");
            summary.AssetsByCategory = GetLookupStats(connection, @"
SELECT c.category_name AS name, COUNT(*) AS value
FROM asset_mgmt.assets a
INNER JOIN asset_mgmt.asset_categories c ON c.category_code = a.category_code
GROUP BY c.category_name
ORDER BY COUNT(*) DESC;");
            summary.UsersByRole = GetLookupStats(connection, @"
SELECT ar.role_name AS name, COUNT(*) AS value
FROM asset_mgmt.system_users su
INNER JOIN asset_mgmt.app_roles ar ON ar.role_code = su.role_code
GROUP BY ar.role_name
ORDER BY COUNT(*) DESC;");
            summary.TopAssets = GetTopAssets(connection);
        }
        catch
        {
            summary.TotalAssets = 120;
            summary.TotalUsers = 20;
            summary.AssetsByCategory = new List<LookupItem>
            {
                new() { Code = "12", Name = "Компьютерная техника" },
                new() { Code = "10", Name = "Сетевое оборудование" },
                new() { Code = "9", Name = "Лицензии и подписки" }
            };
            summary.UsersByRole = new List<LookupItem>
            {
                new() { Code = "12", Name = "Пользователь" },
                new() { Code = "6", Name = "Менеджер" },
                new() { Code = "2", Name = "Администратор" }
            };
            summary.TopAssets = new List<string>
            {
                "Сервер Dell PowerEdge #15",
                "Ноутбук Lenovo ThinkPad #11",
                "IP-камера Hikvision #9",
                "Погрузчик электрический #24",
                "POS-терминал #31"
            };
        }

        return summary;
    }

    private static int ExecuteInt(SqlConnection connection, string sql)
    {
        using var command = new SqlCommand(sql, connection);
        return Convert.ToInt32(command.ExecuteScalar());
    }

    private static List<LookupItem> GetLookupStats(SqlConnection connection, string sql)
    {
        var list = new List<LookupItem>();
        using var command = new SqlCommand(sql, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
        {
            list.Add(new LookupItem
            {
                Code = reader["value"]?.ToString() ?? "0",
                Name = reader["name"]?.ToString() ?? string.Empty
            });
        }
        return list;
    }

    private static List<string> GetTopAssets(SqlConnection connection)
    {
        var items = new List<string>();
        const string sql = @"
SELECT TOP 5 asset_name
FROM asset_mgmt.assets
ORDER BY created_at DESC, asset_name ASC;";
        using var command = new SqlCommand(sql, connection);
        using var reader = command.ExecuteReader();
        while (reader.Read())
            items.Add(reader["asset_name"]?.ToString() ?? string.Empty);
        return items;
    }

    private static IEnumerable<UserAdminItem> GetFallbackUsers(string? search)
    {
        var users = new List<UserAdminItem>
        {
            new() { UserCode = "DEMO001", EmployeeCode = "EMP001", FullName = "Демо Администратор", Email = "admin@demo.local", LoginName = "admin", RoleCode = "ADMIN", RoleName = "Администратор", IsBlocked = false },
            new() { UserCode = "DEMO002", EmployeeCode = "EMP002", FullName = "Демо Менеджер", Email = "manager@demo.local", LoginName = "manager", RoleCode = "MANAGER", RoleName = "Менеджер", IsBlocked = false },
            new() { UserCode = "DEMO003", EmployeeCode = "EMP003", FullName = "Демо Пользователь", Email = "user@demo.local", LoginName = "user", RoleCode = "USER", RoleName = "Пользователь", IsBlocked = false }
        };

        if (string.IsNullOrWhiteSpace(search))
            return users;

        return users.FindAll(u =>
            u.FullName.Contains(search, StringComparison.OrdinalIgnoreCase) ||
            u.Email.Contains(search, StringComparison.OrdinalIgnoreCase) ||
            u.LoginName.Contains(search, StringComparison.OrdinalIgnoreCase));
    }
}
