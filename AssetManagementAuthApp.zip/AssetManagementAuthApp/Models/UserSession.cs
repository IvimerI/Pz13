namespace AssetManagementAuthApp.Models;

public class UserSession
{
    public string UserCode { get; set; } = string.Empty;
    public string EmployeeCode { get; set; } = string.Empty;
    public string LoginName { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string RoleCode { get; set; } = "USER";
    public string RoleName { get; set; } = "Пользователь";
    public UserRole Role { get; set; } = UserRole.User;
    public bool IsBlocked { get; set; }

    public bool IsAdmin => Role == UserRole.Admin;
    public bool CanManageAssets => Role == UserRole.Admin || Role == UserRole.Manager;
}
