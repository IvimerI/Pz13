namespace AssetManagementAuthApp.Models;

public class LookupItem
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;

    public override string ToString() => Name;
}
