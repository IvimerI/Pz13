namespace AssetManagementAuthApp.Models;

public enum UserRole
{
    User,
    Manager,
    Admin
}
