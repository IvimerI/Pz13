using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace AssetManagementAuthApp.Models;

public class AssetCardItem
{
    public string AssetCode { get; set; } = string.Empty;
    public string AssetName { get; set; } = string.Empty;
    public string CategoryName { get; set; } = string.Empty;
    public string StatusName { get; set; } = string.Empty;
    public string LocationName { get; set; } = string.Empty;
    public decimal CurrentValue { get; set; }
    public string Notes { get; set; } = string.Empty;
    public byte[]? ImageBytes { get; set; }

    public string ShortDescription => string.IsNullOrWhiteSpace(Notes)
        ? $"{CategoryName} • {LocationName}"
        : Notes.Length > 90 ? Notes[..90] + "..." : Notes;

    public string ValueText => $"Стоимость: {CurrentValue:N0} руб.";
    public string StatusIcon => StatusName switch
    {
        "В эксплуатации" => "✔",
        "На обслуживании" => "🛠",
        "В ремонте" => "⚙",
        "На складе" => "📦",
        _ => "●"
    };

    public Brush StatusBrush => StatusName switch
    {
        "В эксплуатации" => new SolidColorBrush(Color.FromRgb(0x00, 0x89, 0x7B)),
        "На обслуживании" => new SolidColorBrush(Color.FromRgb(0xF5, 0x7C, 0x00)),
        "В ремонте" => new SolidColorBrush(Color.FromRgb(0xD3, 0x2F, 0x2F)),
        "На складе" => new SolidColorBrush(Color.FromRgb(0x45, 0x55, 0xA4)),
        _ => new SolidColorBrush(Color.FromRgb(0x60, 0x7D, 0x8B))
    };

    public ImageSource? DisplayImage => CreateImage(ImageBytes);

    private static ImageSource? CreateImage(byte[]? bytes)
    {
        if (bytes == null || bytes.Length == 0)
            return null;

        try
        {
            using var stream = new MemoryStream(bytes);
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = stream;
            image.EndInit();
            image.Freeze();
            return image;
        }
        catch
        {
            return null;
        }
    }
}
