using System;

namespace AssetManagementAuthApp.Models;

public class AssetEditItem
{
    public string AssetCode { get; set; } = string.Empty;
    public string AssetName { get; set; } = string.Empty;
    public string CategoryCode { get; set; } = string.Empty;
    public string InventoryNumber { get; set; } = string.Empty;
    public string SerialNumber { get; set; } = string.Empty;
    public string Barcode { get; set; } = string.Empty;
    public DateTime AcquisitionDate { get; set; } = DateTime.Today;
    public decimal InitialCost { get; set; }
    public decimal CurrentValue { get; set; }
    public int UsefulLifeMonths { get; set; } = 12;
    public string StatusCode { get; set; } = string.Empty;
    public string LocationCode { get; set; } = string.Empty;
    public string ResponsibleCode { get; set; } = string.Empty;
    public string VendorCode { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public byte[]? ImageBytes { get; set; }
}
