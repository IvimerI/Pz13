using System.Collections.Generic;

namespace AssetManagementAuthApp.Models;

public class AssetFilterOptions
{
    public List<LookupItem> Categories { get; set; } = new();
    public List<LookupItem> Statuses { get; set; } = new();
    public List<LookupItem> Locations { get; set; } = new();
    public List<LookupItem> Employees { get; set; } = new();
    public List<LookupItem> Vendors { get; set; } = new();
}
