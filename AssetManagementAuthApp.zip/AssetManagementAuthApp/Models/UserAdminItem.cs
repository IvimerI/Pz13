namespace AssetManagementAuthApp.Models;

public class UserAdminItem
{
    public string UserCode { get; set; } = string.Empty;
    public string EmployeeCode { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string LoginName { get; set; } = string.Empty;
    public string RoleCode { get; set; } = string.Empty;
    public string RoleName { get; set; } = string.Empty;
    public bool IsBlocked { get; set; }
    public string StatusText => IsBlocked ? "Заблокирован" : "Активен";
}
