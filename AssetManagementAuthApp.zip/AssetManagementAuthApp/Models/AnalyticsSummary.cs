using System.Collections.Generic;

namespace AssetManagementAuthApp.Models;

public class AnalyticsSummary
{
    public int TotalAssets { get; set; }
    public int TotalUsers { get; set; }
    public List<LookupItem> AssetsByCategory { get; set; } = new();
    public List<string> TopAssets { get; set; } = new();
    public List<LookupItem> UsersByRole { get; set; } = new();
}
