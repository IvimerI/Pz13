using System.Windows;
using System.Windows.Controls;
using AssetManagementAuthApp.Services;

namespace AssetManagementAuthApp.Pages;

public partial class LoginPage : Page
{
    private readonly Frame _frame;

    public LoginPage(Frame frame)
    {
        InitializeComponent();
        _frame = frame;
        AppSession.Clear();
    }

    private void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        if (!AuthService.TryAuthenticate(LoginTextBox.Text, PasswordInput.Password, out var session, out var errorMessage))
        {
            MessageBox.Show(errorMessage, "Авторизация", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        MessageBox.Show($"Добро пожаловать, {session!.FullName}!\nРоль: {session.RoleName}.", "Вход", MessageBoxButton.OK, MessageBoxImage.Information);
        _frame.Navigate(new CatalogPage(_frame));
    }

    private void RegisterLinkButton_Click(object sender, RoutedEventArgs e)
    {
        _frame.Navigate(new RegistrationPage(_frame));
    }
}
