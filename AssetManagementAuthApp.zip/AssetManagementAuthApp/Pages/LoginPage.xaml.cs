using System.Windows;
using System.Windows.Controls;

namespace AssetManagementAuthApp.Pages;

public partial class LoginPage : Page
{
    private readonly Frame _frame;

    public LoginPage(Frame frame)
    {
        InitializeComponent();
        _frame = frame;
    }

    private void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(LoginTextBox.Text) || string.IsNullOrWhiteSpace(PasswordInput.Password))
        {
            MessageBox.Show("Введите логин/email и пароль.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        MessageBox.Show("Авторизация выполнена в демонстрационном режиме.", "Вход", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    private void RegisterLinkButton_Click(object sender, RoutedEventArgs e)
    {
        _frame.Navigate(new RegistrationPage(_frame));
    }
}
