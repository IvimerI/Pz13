using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using AssetManagementAuthApp.Models;
using AssetManagementAuthApp.Services;

namespace AssetManagementAuthApp.Pages;

public partial class AdminPanelPage : Page
{
    private readonly Frame _frame;

    public AdminPanelPage(Frame frame)
    {
        InitializeComponent();
        _frame = frame;

        if (AppSession.CurrentUser?.IsAdmin != true)
        {
            MessageBox.Show("Доступ к административной панели разрешен только администратору.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Warning);
            _frame.Navigate(new CatalogPage(_frame));
            return;
        }

        LoadUsers();
        LoadAnalytics();
    }

    private void LoadUsers()
    {
        UsersDataGrid.ItemsSource = AdminService.GetUsers(UserSearchTextBox.Text);
    }

    private void LoadAnalytics()
    {
        var analytics = AdminService.GetAnalytics();
        TotalAssetsTextBlock.Text = analytics.TotalAssets.ToString();
        TotalUsersTextBlock.Text = analytics.TotalUsers.ToString();
        CategoryStatsItemsControl.ItemsSource = analytics.AssetsByCategory;
        UserStatsItemsControl.ItemsSource = analytics.UsersByRole;
        TopAssetsItemsControl.ItemsSource = analytics.TopAssets.Select((name, index) => $"{index + 1}. {name}");
    }

    private void UserSearchTextBox_TextChanged(object sender, TextChangedEventArgs e) => LoadUsers();
    private void RefreshUsersButton_Click(object sender, RoutedEventArgs e)
    {
        LoadUsers();
        LoadAnalytics();
    }

    private void ChangeRoleButton_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.Tag is not UserAdminItem user)
            return;

        var nextRole = user.RoleCode switch
        {
            "USER" => "MANAGER",
            "MANAGER" => "ADMIN",
            _ => "USER"
        };

        try
        {
            AdminService.UpdateUserRole(user.UserCode, nextRole);
            MessageBox.Show($"Роль пользователя изменена на {nextRole}.", "Управление пользователями", MessageBoxButton.OK, MessageBoxImage.Information);
            LoadUsers();
            LoadAnalytics();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось изменить роль.\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ToggleBlockButton_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.Tag is not UserAdminItem user)
            return;

        try
        {
            AdminService.SetBlocked(user.UserCode, !user.IsBlocked);
            MessageBox.Show(user.IsBlocked ? "Пользователь разблокирован." : "Пользователь заблокирован.", "Управление пользователями", MessageBoxButton.OK, MessageBoxImage.Information);
            LoadUsers();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось обновить статус блокировки.\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void BackToCatalogButton_Click(object sender, RoutedEventArgs e)
    {
        _frame.Navigate(new CatalogPage(_frame));
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e)
    {
        AppSession.Clear();
        _frame.Navigate(new LoginPage(_frame));
    }
}
