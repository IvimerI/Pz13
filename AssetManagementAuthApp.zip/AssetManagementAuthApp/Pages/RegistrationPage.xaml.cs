using System.Windows;
using System.Windows.Controls;

namespace AssetManagementAuthApp.Pages;

public partial class RegistrationPage : Page
{
    private readonly Frame _frame;

    public RegistrationPage(Frame frame)
    {
        InitializeComponent();
        _frame = frame;
    }

    private void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(FullNameTextBox.Text) ||
            string.IsNullOrWhiteSpace(EmailTextBox.Text) ||
            string.IsNullOrWhiteSpace(PasswordBox.Password) ||
            string.IsNullOrWhiteSpace(ConfirmPasswordBox.Password))
        {
            MessageBox.Show("Заполните все поля.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (!PasswordBox.Password.Equals(ConfirmPasswordBox.Password))
        {
            MessageBox.Show("Пароли не совпадают.", "Ошибка регистрации", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        MessageBox.Show("Регистрация в разработке", "Регистрация", MessageBoxButton.OK, MessageBoxImage.Information);
        _frame.Navigate(new CatalogPage(_frame));
    }

    private void BackToLoginButton_Click(object sender, RoutedEventArgs e)
    {
        _frame.Navigate(new LoginPage(_frame));
    }
}
