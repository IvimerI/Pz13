using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using AssetManagementAuthApp.Models;
using AssetManagementAuthApp.Services;
using Microsoft.Win32;

namespace AssetManagementAuthApp.Pages;

public partial class AddEditPage : Page
{
    private readonly Frame? _frame;
    private readonly string? _assetCode;
    private readonly bool _isEditMode;
    private byte[]? _imageBytes;

    public AddEditPage(Frame? frame = null, string? assetCode = null)
    {
        InitializeComponent();
        _frame = frame;
        _assetCode = assetCode;
        _isEditMode = !string.IsNullOrWhiteSpace(assetCode);
        LoadLookups();
        InitializeDefaults();

        if (_isEditMode)
            LoadAsset();
    }

    private void LoadLookups()
    {
        var options = AssetCatalogService.GetFilterOptions();
        CategoryComboBox.ItemsSource = options.Categories;
        StatusComboBox.ItemsSource = options.Statuses;
        LocationComboBox.ItemsSource = options.Locations;
        ResponsibleComboBox.ItemsSource = options.Employees;

        var vendors = options.Vendors;
        vendors.Insert(0, new LookupItem { Code = string.Empty, Name = "Без поставщика" });
        VendorComboBox.ItemsSource = vendors;
    }

    private void InitializeDefaults()
    {
        AcquisitionDatePicker.SelectedDate = DateTime.Today;
        UsefulLifeTextBox.Text = "60";
        InitialCostTextBox.Text = "0";
        CurrentValueTextBox.Text = "0";
        VendorComboBox.SelectedIndex = 0;

        if (_isEditMode)
        {
            PageTitleTextBlock.Text = "Редактирование актива";
            AssetCodeTextBox.IsReadOnly = true;
            AssetCodeTextBox.Opacity = 0.85;
        }
        else
        {
            PageTitleTextBlock.Text = "Добавление актива";
        }
    }

    private void LoadAsset()
    {
        try
        {
            var item = AssetCatalogService.GetAssetByCode(_assetCode!);
            if (item == null)
            {
                MessageBox.Show("Запись не найдена.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                NavigateBack();
                return;
            }

            AssetCodeTextBox.Text = item.AssetCode;
            AssetNameTextBox.Text = item.AssetName;
            CategoryComboBox.SelectedValue = item.CategoryCode;
            InventoryNumberTextBox.Text = item.InventoryNumber;
            SerialNumberTextBox.Text = item.SerialNumber;
            BarcodeTextBox.Text = item.Barcode;
            AcquisitionDatePicker.SelectedDate = item.AcquisitionDate;
            InitialCostTextBox.Text = item.InitialCost.ToString("0.##");
            CurrentValueTextBox.Text = item.CurrentValue.ToString("0.##");
            UsefulLifeTextBox.Text = item.UsefulLifeMonths.ToString();
            StatusComboBox.SelectedValue = item.StatusCode;
            LocationComboBox.SelectedValue = item.LocationCode;
            ResponsibleComboBox.SelectedValue = item.ResponsibleCode;
            VendorComboBox.SelectedValue = item.VendorCode;
            NotesTextBox.Text = item.Notes;
            _imageBytes = item.ImageBytes;
            UpdatePreview();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось загрузить запись.\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void LoadImageButton_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Изображения|*.png;*.jpg;*.jpeg;*.bmp",
            Title = "Выбор изображения"
        };

        if (dialog.ShowDialog() != true)
            return;

        _imageBytes = File.ReadAllBytes(dialog.FileName);
        UpdatePreview();
    }

    private void ClearImageButton_Click(object sender, RoutedEventArgs e)
    {
        _imageBytes = null;
        UpdatePreview();
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        if (!ValidateInputs(out var item))
            return;

        try
        {
            if (_isEditMode)
                AssetCatalogService.UpdateAsset(item);
            else
                AssetCatalogService.AddAsset(item);

            MessageBox.Show("Изменения сохранены.", "Сохранение", MessageBoxButton.OK, MessageBoxImage.Information);
            NavigateBack();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось сохранить данные.\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private bool ValidateInputs(out AssetEditItem item)
    {
        item = new AssetEditItem();

        if (string.IsNullOrWhiteSpace(AssetCodeTextBox.Text) ||
            string.IsNullOrWhiteSpace(AssetNameTextBox.Text) ||
            string.IsNullOrWhiteSpace(InventoryNumberTextBox.Text) ||
            string.IsNullOrWhiteSpace(SerialNumberTextBox.Text))
        {
            MessageBox.Show("Заполните обязательные поля: код, наименование, инвентарный номер и серийный номер.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        if (CategoryComboBox.SelectedValue == null || StatusComboBox.SelectedValue == null ||
            LocationComboBox.SelectedValue == null || ResponsibleComboBox.SelectedValue == null)
        {
            MessageBox.Show("Выберите категорию, статус, место расположения и ответственного.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        if (AcquisitionDatePicker.SelectedDate == null)
        {
            MessageBox.Show("Укажите дату приобретения.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        if (!decimal.TryParse(InitialCostTextBox.Text, out var initialCost) || initialCost < 0)
        {
            MessageBox.Show("Первоначальная стоимость должна быть неотрицательным числом.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        if (!decimal.TryParse(CurrentValueTextBox.Text, out var currentValue) || currentValue < 0)
        {
            MessageBox.Show("Текущая стоимость должна быть неотрицательным числом.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        if (!int.TryParse(UsefulLifeTextBox.Text, out var usefulLife) || usefulLife <= 0)
        {
            MessageBox.Show("Срок полезного использования должен быть положительным целым числом.", "Проверка данных", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }

        item = new AssetEditItem
        {
            AssetCode = AssetCodeTextBox.Text.Trim(),
            AssetName = AssetNameTextBox.Text.Trim(),
            CategoryCode = CategoryComboBox.SelectedValue.ToString() ?? string.Empty,
            InventoryNumber = InventoryNumberTextBox.Text.Trim(),
            SerialNumber = SerialNumberTextBox.Text.Trim(),
            Barcode = BarcodeTextBox.Text.Trim(),
            AcquisitionDate = AcquisitionDatePicker.SelectedDate.Value,
            InitialCost = initialCost,
            CurrentValue = currentValue,
            UsefulLifeMonths = usefulLife,
            StatusCode = StatusComboBox.SelectedValue.ToString() ?? string.Empty,
            LocationCode = LocationComboBox.SelectedValue.ToString() ?? string.Empty,
            ResponsibleCode = ResponsibleComboBox.SelectedValue.ToString() ?? string.Empty,
            VendorCode = VendorComboBox.SelectedValue?.ToString() ?? string.Empty,
            Notes = NotesTextBox.Text.Trim(),
            ImageBytes = _imageBytes
        };

        return true;
    }

    private void UpdatePreview()
    {
        if (_imageBytes == null || _imageBytes.Length == 0)
        {
            PreviewImage.Source = null;
            PlaceholderPanel.Visibility = Visibility.Visible;
            return;
        }

        try
        {
            using var stream = new MemoryStream(_imageBytes);
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.StreamSource = stream;
            image.EndInit();
            image.Freeze();
            PreviewImage.Source = image;
            PlaceholderPanel.Visibility = Visibility.Collapsed;
        }
        catch
        {
            PreviewImage.Source = null;
            PlaceholderPanel.Visibility = Visibility.Visible;
        }
    }

    private void BackButton_Click(object sender, RoutedEventArgs e) => NavigateBack();
    private void CancelButton_Click(object sender, RoutedEventArgs e) => NavigateBack();

    private void NavigateBack()
    {
        if (_frame != null)
        {
            _frame.Navigate(new CatalogPage(_frame));
            return;
        }

        NavigationService?.Navigate(new CatalogPage());
    }
}
