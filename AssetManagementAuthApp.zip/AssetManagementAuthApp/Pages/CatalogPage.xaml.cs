using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using AssetManagementAuthApp.Models;
using AssetManagementAuthApp.Services;

namespace AssetManagementAuthApp.Pages;

public partial class CatalogPage : Page
{
    private readonly Frame? _frame;
    private bool _isInitialized;

    public CatalogPage()
    {
        InitializeComponent();
        ConfigureFilters();
        ApplyRoleRules();
    }

    public CatalogPage(Frame frame)
    {
        InitializeComponent();
        _frame = frame;
        ConfigureFilters();
        ApplyRoleRules();
    }

    private void ApplyRoleRules()
    {
        var user = AppSession.CurrentUser;
        if (user == null)
        {
            WelcomeTextBlock.Text = "Гость";
            AddButton.Visibility = Visibility.Collapsed;
            EditButton.Visibility = Visibility.Collapsed;
            DeleteButton.Visibility = Visibility.Collapsed;
            AdminPanelButton.Visibility = Visibility.Collapsed;
            return;
        }

        WelcomeTextBlock.Text = $"Пользователь: {user.FullName} · Роль: {user.RoleName}";
        var canManage = user.CanManageAssets;
        AddButton.Visibility = canManage ? Visibility.Visible : Visibility.Collapsed;
        EditButton.Visibility = canManage ? Visibility.Visible : Visibility.Collapsed;
        DeleteButton.Visibility = canManage ? Visibility.Visible : Visibility.Collapsed;
        AdminPanelButton.Visibility = user.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
    }

    private void ConfigureFilters()
    {
        var options = AssetCatalogService.GetFilterOptions();

        var categories = new List<LookupItem> { new() { Code = string.Empty, Name = "Все категории" } };
        categories.AddRange(options.Categories);
        CategoryComboBox.ItemsSource = categories;
        CategoryComboBox.SelectedIndex = 0;

        var statuses = new List<LookupItem> { new() { Code = string.Empty, Name = "Все статусы" } };
        statuses.AddRange(options.Statuses);
        StatusComboBox.ItemsSource = statuses;
        StatusComboBox.SelectedIndex = 0;

        _isInitialized = true;
        LoadAssets();
    }

    private void LoadAssets()
    {
        if (!_isInitialized)
            return;

        var categoryCode = CategoryComboBox.SelectedValue?.ToString();
        var statusCode = StatusComboBox.SelectedValue?.ToString();
        var sortField = (SortFieldComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString();
        var descending = ((SortDirectionComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString()) == "По убыванию";

        var assets = AssetCatalogService.GetAssets(SearchTextBox.Text, categoryCode, statusCode, sortField, descending);
        AssetsListView.ItemsSource = assets;
        StatusTextBlock.Text = $"Найдено записей: {assets.Count}";
    }

    private AssetCardItem? GetSelectedAsset() => AssetsListView.SelectedItem as AssetCardItem;
    private bool EnsureManagePermission()
    {
        if (AppSession.CurrentUser?.CanManageAssets == true)
            return true;

        MessageBox.Show("Эта операция доступна только менеджеру или администратору.", "Недостаточно прав", MessageBoxButton.OK, MessageBoxImage.Warning);
        return false;
    }

    private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e) => LoadAssets();
    private void Filters_Changed(object sender, SelectionChangedEventArgs e) => LoadAssets();
    private void RefreshButton_Click(object sender, RoutedEventArgs e) => LoadAssets();

    private void AddButton_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureManagePermission())
            return;

        if (_frame != null)
        {
            _frame.Navigate(new AddEditPage(_frame));
            return;
        }

        NavigationService?.Navigate(new AddEditPage());
    }

    private void EditButton_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureManagePermission())
            return;

        var selected = GetSelectedAsset();
        if (selected == null)
        {
            MessageBox.Show("Выберите запись для редактирования.", "Редактирование", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (_frame != null)
        {
            _frame.Navigate(new AddEditPage(_frame, selected.AssetCode));
            return;
        }

        NavigationService?.Navigate(new AddEditPage(null, selected.AssetCode));
    }

    private void DeleteButton_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsureManagePermission())
            return;

        var selected = GetSelectedAsset();
        if (selected == null)
        {
            MessageBox.Show("Выберите запись для удаления.", "Удаление", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var answer = MessageBox.Show($"Удалить актив \"{selected.AssetName}\"?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes)
            return;

        try
        {
            AssetCatalogService.DeleteAsset(selected.AssetCode);
            LoadAssets();
            MessageBox.Show("Запись удалена.", "Удаление", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось удалить запись.\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void AdminPanelButton_Click(object sender, RoutedEventArgs e)
    {
        if (AppSession.CurrentUser?.IsAdmin != true)
        {
            MessageBox.Show("Админ-панель доступна только администратору.", "Доступ запрещен", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _frame?.Navigate(new AdminPanelPage(_frame));
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e)
    {
        AppSession.Clear();
        _frame?.Navigate(new LoginPage(_frame!));
    }
}
