using System.Windows;

namespace AssetManagementAuthApp;

public partial class App : Application
{
}
